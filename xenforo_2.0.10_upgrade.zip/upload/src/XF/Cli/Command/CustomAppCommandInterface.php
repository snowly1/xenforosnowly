<?php

namespace XF\Cli\Command;

interface CustomAppCommandInterface
{
	public static function getCustomAppClass();
}